package com.example.hello;

public class Posts {
	
	private static String attributes1;
	private static String[] attributes;

	public static void main(String[] args) {
		setAttributes(new String[] {"ID", "authorID", "Bread"});
		setAttributes1("timeStamp");
		
	}

	public static String[] getAttributes() {
		return attributes;
	}

	public static void setAttributes(String[] attributes) {
		Posts.attributes = attributes;
	}

	public static String getAttributes1() {
		return attributes1;
	}

	public static void setAttributes1(String attributes1) {
		Posts.attributes1 = attributes1;
	}
}

	
	

