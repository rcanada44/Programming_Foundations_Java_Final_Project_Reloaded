package com.example.hello;

public class LocalDateTime {
	 
	public static void main(String[]args) {
		int i = 0;
		while(i<11) {
		   System.out.println(i);
		   i++;
		
	}
	}
}


