package com.example.hello;

public class Users {
	
	private static String name;
	private static String name2;
	private static String challege;
	private static String answer;
	private static String userInfo;

	public static void main(String[] args) {
	String object = "ID";
	setName("firstName");
	setName2("lastName");
	setChallege("userName");
	setAnswer("password");
	int length = object.length();
	setUserInfo(object + "" + name);
	System.out.println(length);
	
}

	public static String getName() {
		return name;
	}

	public static void setName(String name) {
		Users.name = name;
	}

	public static String getName2() {
		return name2;
	}

	public static void setName2(String name2) {
		Users.name2 = name2;
	}

	public static String getChallege() {
		return challege;
	}

	public static void setChallege(String challege) {
		Users.challege = challege;
	}

	public static String getAnswer() {
		return answer;
	}

	public static void setAnswer(String answer) {
		Users.answer = answer;
	}

	public static String getUserInfo() {
		return userInfo;
	}

	public static void setUserInfo(String userInfo) {
		Users.userInfo = userInfo;
	}

}
