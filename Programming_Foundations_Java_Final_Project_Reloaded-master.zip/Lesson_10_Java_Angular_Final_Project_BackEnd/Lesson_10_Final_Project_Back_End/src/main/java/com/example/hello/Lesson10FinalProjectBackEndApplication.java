package com.example.hello;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lesson10FinalProjectBackEndApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lesson10FinalProjectBackEndApplication.class, args);
	}
}
